package com.vincentmartinez.logicgame.implementation;

//import java.io.DataInputStream;
//	import java.io.DataOutputStream;
//	import java.io.EOFException;
//	import java.io.FileInputStream;
//	import java.io.FileOutputStream;
//	import java.io.IOException;
//	import java.nio.*;
//	import java.util.ArrayList;
//	import java.util.InputMismatchException;
//	import java.util.Scanner;
//
//	public class PropertiesHelper {
//
//		private static int securityLoop = 0;
//		private static int nbEssai = 0;
//		private static int nbChiffre = 0;
//		private static int nbCouleur = 0;
//		
//		public static void write() throws IOException {
//			String nomFichier;
//			int n = 0;
//			Scanner sc = new Scanner(System.in);
//			System.out.println("Donnez le nom du fichier a creer : ");
//			nomFichier = sc.nextLine();
//			DataOutputStream sortie = new DataOutputStream(new FileOutputStream(nomFichier));
//			do {
//				do {
//					securityLoop = 0;
//					try {
//						System.out.println("Donnez le nombre d'essai souhaites (entre 4 et 40) : ");
//						n = sc.nextInt();
//					} catch (InputMismatchException e) {
//
//						System.out.println("L'information que vous avez renseigne ne convient pas, merci de reessayer ! ");
//						securityLoop = 1;
//					}
//
//					if (n < 4 || n > 40) {
//						System.out.println("Le chiffre renseigne ne correspond pas aux limitations en vigueur ! ");
//						securityLoop = 1;
//					}
//
//				} while (securityLoop == 1);
//
//				sortie.writeInt(n);
//
//				do {
//					securityLoop = 0;
//					try {
//
//						System.out.println("Donnez le nombre de chiffres a trouver (entre 4 et 10) :");
//						n = sc.nextInt();
//					} catch (InputMismatchException e) {
//						System.out.println("L'information que vous avez renseigne ne convient pas, merci de reessayer ! ");
//						securityLoop = 1;
//						break;
//					}
//					if (n < 4 || n > 10) {
//						System.out.println("Le chiffre renseigne ne correspond pas aux limitations en vigueur ! ");
//						securityLoop = 1;
//						break;
//					}
//				} while (securityLoop == 1);
//
//				sortie.writeInt(n);
//
//				do {
//					securityLoop = 0;
//					try {
//
//						System.out.println("Donnez le nombre de couleurs a trouver (entre 4 et 8) ");
//						n = sc.nextInt();
//					} catch (InputMismatchException e) {
//						System.out.println("L'information que vous avez renseigne ne convient pas, merci de reessayer ! ");
//						securityLoop = 1;
//						break;
//					}
//					if (n < 4 || n > 8) {
//						System.out.println("Le chiffre renseigne ne correspond pas aux limitations en vigueur ! ");
//						securityLoop = 1;
//						break;
//					}
//				} while (securityLoop == 1);
//
//				sortie.writeInt(n);
//
//				n = 0;
//
//			} while (n != 0);
//			sortie.close();
//			System.out.println("**** fin creation fichier ****");
//
//		}
//
//		public static void read() throws IOException {
//
//			String nomFichier;
//			int n = 0;
//			Scanner sc = new Scanner(System.in);
//			System.out.println("Donnez le nom du fichier a lister : ");
//			nomFichier = sc.nextLine();
//			DataInputStream entree = new DataInputStream(new FileInputStream(nomFichier));
//
//			System.out.println("Valeurs lues dans le fichier : ");
//			boolean eof = false;
//			while (!eof) {
//				
//				try {
//					nbEssai = entree.readInt();
//
//				} catch (EOFException e) {
//					eof = true;
//				}
//
//				try {
//					setNbChiffre(entree.readInt());
//
//				} catch (EOFException e) {
//					eof = true;
//				}
//
//
//				try {
//					nbCouleur = entree.readInt();
//
//				} catch (EOFException e) {
//					eof = true;
//				}
//
//				
//			entree.close();
//			sc.close();
//
//			System.out.println("**** fin liste fichier **** ");
//			System.out.println("nbEssai : " +nbEssai);
//			System.out.println("nbChiffre : " +getNbChiffre());
//			System.out.println("nbCouleur : " +nbCouleur);
//			
//		
//
//			}
//
//		}
//
//		public static int getNbChiffre() {
//			return nbChiffre;
//		}
//
//		public static void setNbChiffre(int nbChiffre) {
//			PropertiesHelper.nbChiffre = nbChiffre;
//		}
//		}

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import org.apache.log4j.*;
import org.apache.log4j.Logger;

import java.util.InputMismatchException;
import java.lang.NullPointerException;


public class PropertiesHelper {
	
	final static Logger logger = Logger.getLogger(com.vincentmartinez.logicgame.implementation.PropertiesHelper.class);

	/** nombre d'essais. */
	private static Integer nbEssai;

	private static Integer nbChiffre;

	private static Integer nbCouleur;

	private static Boolean modeDev;

	public static Boolean getModeDev() {
		return modeDev;
	}

	public static void setModeDev(Boolean modeDev) {
		PropertiesHelper.modeDev = modeDev;
	}

	public static Integer getNbEssai() {
		return nbEssai;
	}

	public static Integer getNbChiffre() {
		return nbChiffre;
	}

	public static Integer getNbCouleur() {
		return nbCouleur;
	}

	public static void init() {
		String nomFich;
		String ligne = null;
		BufferedReader entree = null;
		int securityLoop;
		do {
			do {
			securityLoop = 0;
			
			Scanner sc = new Scanner(System.in);

//		int x = 0;

			System.out.println("donnez le nom du fichier a lister");
			nomFich = sc.nextLine();

			

			try {
				entree = new BufferedReader(new FileReader(nomFich));

				ligne = entree.readLine();
			} catch (IOException |NullPointerException e) {
				//System.out.println("fichier non trouve, merci de proposer un autre import ");
				logger.error("fichier non trouve, merci de proposer un autre import ");
				securityLoop =1;
			}
			}while(securityLoop==1);
			
			logger.trace("fichier "+nomFich+" charge avec succes");
			while (ligne != null) {
				if (ligne != null) {

					String[] contain = ligne.split(":");

					String variable = contain[0];

					String valeurDesVariables = contain[1];

					try {
						if (variable.equals("nbEssai")) {
							nbEssai = Integer.parseInt(valeurDesVariables);
						}
					 
						if (variable.equals("nbChiffre")) {
							nbChiffre = Integer.parseInt(valeurDesVariables);
						}
				
					
						if (variable.equals("nbCouleur")) {
							nbCouleur = Integer.parseInt(valeurDesVariables);
						}
				
					
				
						if (variable.equals("modeDev")) {
							modeDev = Boolean.parseBoolean(valeurDesVariables);
						}
						
					} catch (InputMismatchException e) {
						logger.warn("Les donnees renseignees dans le fichier ne semble pas bonnes, merci de modifier :");
						securityLoop = 1;

					}
					securityLoop = 1;
					try {
						ligne = entree.readLine();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			} // fin du While

			try {

				entree.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
//			System.out.println("Conformement au fichier " + nomFich + " : ");
			System.out.println("Nombre d'Essais : " + getNbEssai());
			System.out.println("Nombre de Chiffres : " + getNbChiffre());
			System.out.println("Nombre de Couleurs : " + getNbCouleur());
			if (nbCouleur < 4 || nbCouleur > 10) {
				System.out.println(
						"Le nombre renseign� pour la Couleur ne convient pas, merci de modifier votre fichier");
				securityLoop = 1;
				break;
			} else {
				securityLoop = 0;
			}
			System.out.println("Mode Developpeur : " + getModeDev());

		} while (securityLoop == 1);
	}
}

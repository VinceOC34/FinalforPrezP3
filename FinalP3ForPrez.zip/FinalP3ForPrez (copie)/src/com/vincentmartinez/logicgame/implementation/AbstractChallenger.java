package com.vincentmartinez.logicgame.implementation;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

import org.apache.log4j.Logger;



public abstract class AbstractChallenger extends AbstractGAME {

	final static Logger logger = Logger.getLogger(com.vincentmartinez.logicgame.implementation.AbstractChallenger.class);
	/*
	 * ici la methode combi correspond a la combinaison cachee par l'ordinateur car
	 * en mode challenger, c'est toujours l'ordi qui cache sa combinaison quel que
	 * soit le jeux
	 */

	public void Combi() {

		Random rand = new Random();
		System.out.println("L'ordinateur a choisi une combinaison a " + PropertiesHelper.getNbChiffre() + " chiffres.");
		// int [] randTab = new int [getNbChiffre()];

		for (int i = 0; i < PropertiesHelper.getNbChiffre(); i++) {

			// ici on utilise la fonction nextInt(et la limite NON INCLUE dans la
			// parenthese)

			int nombreAleatoire = rand.nextInt(10);
			ComputeCombi.add(nombreAleatoire);
			// Ici je stocke les nombres aleatoires dans un tableau de la taille de la
			// combinaison souhaitee

			if (PropertiesHelper.getModeDev() == true) {// si mode developpeur selectionne, je montre la combinaison de
														// l'ordinateur
				System.out.print(ComputeCombi.get(i) + "|");
			} else {
			}
			

		}
		System.out.println();
	}

	
	public void Attack() {
		do {
			try {
				int securtiyLoop = 0;
				UserAttack.clear();
				gagneUser = 0;
				bienPlace = 0;
				malPlace = 0;

				Scanner sc = new Scanner(System.in);

				System.out.println("Lancez votre attaque " + (tentativesUser + 1) + " sur "
						+ PropertiesHelper.getNbEssai() + " :");

				// Je scanne la reponse en String, pour l'utiliser en tableau de
				// char...convertit en int au passage
				String str = sc.nextLine();

				// int [] userAttack = new int [getNbChiffre()];

				System.out.print("Vous avez propose : ");
				for (int j = 0; j < PropertiesHelper.getNbChiffre(); j++) {

					UserAttack.add(Character.getNumericValue(str.charAt(j)));

//			System.out.print(UserAttack.get(j)+"|");
				}
			} catch (InputMismatchException | StringIndexOutOfBoundsException e) {
				if (UserAttack.size() < PropertiesHelper.getNbChiffre()
						|| UserAttack.size() > PropertiesHelper.getNbChiffre()) {
					securityLoop = 1;
					logger.error("L'information saisie ne semble pas appropriee, merci de recommencer :");
					UserAttack.clear();
				}
			}

			System.out.println();
		} while (securityLoop == 1);

		java.util.Iterator<Integer> IUserAttack = UserAttack.iterator();
		while (IUserAttack.hasNext()) {
			System.out.print(IUserAttack.next() + "|");
		}
		System.out.println();
	}

	
	public void Play() {
if (getSelectMode()==1) {
		this.initializeValue();
		this.Combi();
		do {
			this.Attack();

		} while (tentativesUser < PropertiesHelper.getNbEssai() && gagneUser < PropertiesHelper.getNbChiffre());
		this.Results();

	}
else {
	
}
	}

	public void Results() {

		if (gagneUser == PropertiesHelper.getNbChiffre() || tentativesCompute == PropertiesHelper.getNbEssai()) {

			System.out.println("Vous avez gagne ! ");
		}

		else if (gagneCompute == PropertiesHelper.getNbChiffre() || tentativesUser == PropertiesHelper.getNbEssai()) {
			System.out.println("L'ordinateur a gagne ");
			System.out.println(" La combinaison cachee par l'ordinateur etait : ");

			java.util.Iterator<Integer> IComputeCombi = ComputeCombi.iterator();
			while (IComputeCombi.hasNext()) {
				System.out.print(IComputeCombi.next() + "|");
			}

		}

		System.out.println("");
		this.whatsNext();
	}

	public void initializeValue() {
		super.initializeValue();

		UserAttack.clear();
		ComputeCombi.clear();

	}

	protected static ArrayList<Integer> UserAttack = new ArrayList<Integer>();
	protected static ArrayList<Integer> ComputeCombi = new ArrayList<Integer>();// ancien RandTab
}

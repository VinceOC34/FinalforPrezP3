package com.vincentmartinez.logicgame.implementation;

import org.apache.log4j.Logger;

public class MainFinal {

	private static int generalLoop = 0;

	public static void main(String[] args) {
		final Logger logger = Logger.getLogger(com.vincentmartinez.logicgame.implementation.MainFinal.class);
		logger.trace("Lancement du jeux ");
		do {
		
		/* chargement du fichier de parametrage */
			
		PropertiesHelper.init();
		
		/*verification de la composition du args, qui pourrait venir modifier le mode developpeur deja parametre par fichier */
		if (args.length!=0) {
			
			System.out.println("argument1 "+args[0]);
		if (args[0].equals("-dev")) {
			PropertiesHelper.setModeDev(true);
			System.out.println(PropertiesHelper.getModeDev());
		}
		}
		
		
		/* lancement de la selection du jeu */
		
		AbstractGAME.gameSelection();
		
		
	}while (generalLoop ==1);

}
}

package com.vincentmartinez.logicgame.implementation;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

public abstract class AbstractDefender extends AbstractGAME {

	final static Logger logger = Logger.getLogger(com.vincentmartinez.logicgame.implementation.AbstractDefender.class);
	
	public void Combi() {
		int securityLoop = 0;
		String str = null;
		do {
			try {
				securityLoop = 0;
				// L'utilisateur choisi sa combinaison cachee
				Scanner sc = new Scanner(System.in);

				System.out.println("Choisissez votre combinaison a " + PropertiesHelper.getNbChiffre()
						+ " chiffres, qui sera dissimulee :");

				/*
				 * Je scanne la reponse en String, pour l'utiliser en tableau de
				 * char...convertit en int au passage
				 */
				str = sc.nextLine();

				// int [] userInput = new int [getNbChiffre()];

				for (int j = 0; j < PropertiesHelper.getNbChiffre(); j++) {

					UserCombi.add(Character.getNumericValue(str.charAt(j)));
				}

			} catch (InputMismatchException | StringIndexOutOfBoundsException e) {
				if (UserCombi.size() < PropertiesHelper.getNbChiffre()
						|| UserCombi.size() > PropertiesHelper.getNbChiffre()) {
					securityLoop = 1;
					logger.error("L'information saisie ne semble pas appropriee, merci de recommencer :");
					UserCombi.clear();
				}

			}

		} while (securityLoop == 1);
//		sc.close();
		System.out.print("Votre combinaison est : ");
		java.util.Iterator<Integer> IuserCombi = UserCombi.iterator();
		while (IuserCombi.hasNext()) {
			System.out.print(IuserCombi.next() + "|");
		}
		System.out.println();
	}

	public abstract void Attack();

	public void Play() {
if (getSelectMode()==2) {
		this.initializeValue();
		this.Combi();
		do {
			this.Attack();

		} while (tentativesCompute < PropertiesHelper.getNbEssai() && gagneCompute < PropertiesHelper.getNbChiffre());
		this.Results();
}
	
	if (getSelectMode()==3) {
	
	
	}
	}

	public void Results() {

		if (gagneCompute == PropertiesHelper.getNbChiffre() || tentativesUser == PropertiesHelper.getNbEssai()) {
			System.out.println("L'ordinateur a gagne ");

		} else if (gagneUser == PropertiesHelper.getNbChiffre() || tentativesCompute == PropertiesHelper.getNbEssai()) {
			System.out.println("Vous avez gagne ! ");

		}
		System.out.println("");
		this.whatsNext();
	}

	public void initializeValue() {
		super.initializeValue();

	}

	protected static ArrayList<Integer> ComputeAttack = new ArrayList<Integer>();
	protected static ArrayList<Integer> UserCombi = new ArrayList<Integer>();
	protected static ArrayList<Integer> chiffresPossibles = new ArrayList<Integer>();
	protected static ArrayList<Integer> computLoading = new ArrayList<Integer>();
	protected static int nb;

}

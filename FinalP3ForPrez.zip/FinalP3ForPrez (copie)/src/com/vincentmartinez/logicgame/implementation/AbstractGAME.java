package com.vincentmartinez.logicgame.implementation;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.vincentmartinez.mastermind.MM_Challenger;
import com.vincentmartinez.mastermind.MM_Defender;
import com.vincentmartinez.plusoumoins.PLM_Challenger;
import com.vincentmartinez.plusoumoins.PLM_Defender;

public abstract class AbstractGAME implements Game_Interface {
	
	final static Logger logger = Logger.getLogger(com.vincentmartinez.logicgame.implementation.AbstractGAME.class);
	/*
	 * cette classe Abstraite sert a la fois de librairy, aux valeurs communes a
	 * plusieurs classes, et de mise en place des methodes Abstraites et concretes
	 */

	/* Arguments communs a plusieurs classes */

	protected static int gagneCompute = 0;
	protected static int gagneUser = 0;
	protected static int tentativesUser = 0;
	protected static int tentativesCompute = 0;
	protected static int generalLoop = 0;
	protected static int bienPlace = 0;
	protected static int malPlace = 0;
	protected static int securityLoop = 0;

	/* Methodes concretes */
	protected void setSelectGame(int ssg) {
		ssg = selectGame;
	}

	public static int getSelectGame() {
		return selectGame;
	}

	protected void setSelectMode(int ssm) {
		ssm = selectMode;
	}

	public static int getSelectMode() {
		return selectMode;
	}

	public static void gameSelection() {

		int securityLoop = 0;
		Scanner sc = new Scanner(System.in);
		do {// boucle pour relancer le menu, si l'utilisateur choisir "4. retourner au menu
			// general"
			do { // boucle en cas d'erreur de saisie
				try {
					securityLoop = 0;

					sc = new Scanner(System.in);
					System.out.println("A quel jeu souhaitez vous jouer");
					System.out.println("1. Plus ou Moins");
					System.out.println("2. Mastermind");

					selectGame = sc.nextInt();
				} catch (InputMismatchException e) {
					logger.warn("La saisie ne semble pas bonne, merci de recommencer :");
					securityLoop++;
				}
				if (selectGame > 2 || selectGame < 1) {
					securityLoop = 1;
					System.out.println("Le chiffre saisie ne semble pas approprie, merci de recommencer :");
				}

			} while (securityLoop == 1);// fin de la boucle
			do { // boucle en cas d'erreur de saisie
				try {
					securityLoop = 0;
					sc = new Scanner(System.in);
					if (selectGame == 1) {
						System.out.println("Menu Plus ou Moins - Quel mode voulez vous utiliser ?");
					} else if (selectGame == 2) {
						System.out.println("Menu Mastermind - Quel mode voulez vous utiliser ?");
					}

					System.out.println();

					System.out.println("1. Challenger (trouver la combinaison secrete de l'ordinateur)");
					System.out.println("2. Defenseur  (l'ordinateur essaye de trouver votre combinaison secrete)");
					System.out.println("3. Duel       (tour a tour contre l'ordinateur)");
					System.out.println("4. Retourner au menu general pour changer de Jeu");

					selectMode = sc.nextInt();
				} catch (InputMismatchException e) {
					logger.warn("La saisie ne semble pas bonne, merci de recommencer :");
					securityLoop++;
				}
				if (selectMode > 4 || selectMode < 1) {
					securityLoop = 1;
					logger.warn("Le chiffre saisie ne semble pas approprie, merci de recommencer :");
					
				}
			} while (securityLoop == 1);// fin de la boucle

			if (selectMode == 4) {
			}

			else {

			}

		} while (selectMode == 4);
		
		logger.trace("Le joueur a choisi le jeu "+getSelectGame()+" et le mode "+getSelectMode());

		Menu();

	}

	private static void Menu() {

		/*
		 * Objet Commun de type Interface permettant d'utiliser tous les objets des
		 * classes implementant l'Interface
		 */

		Game_Interface select;

		if (selectGame == 1 && selectMode == 1) {
			select = new PLM_Challenger();
		}
		if (selectGame == 1 && selectMode == 2) {
			select = new PLM_Defender();
		}

		if (selectGame == 1 && selectMode == 3) {
			duel();
		}
		if (selectGame == 2 && selectMode == 1) {

			select = new MM_Challenger();
		}
		if (selectGame == 2 && selectMode == 2) {

			select = new MM_Defender();
		}
		if (selectGame == 2 && selectMode == 3) {
			duel();
		}

	}

	private static void duel() {

		Game_Interface selectDuel = null;
		Game_Interface selectDuel2 = null;

		if (selectGame == 2 && selectMode == 3) {
			selectDuel = new MM_Defender();
			selectDuel2 = new MM_Challenger();
		} else if (selectGame == 1 && selectMode == 3) {
			selectDuel = new PLM_Defender();
			selectDuel2 = new PLM_Challenger();
		}

		selectDuel.initializeValue();
		selectDuel2.initializeValue();
		selectDuel.Combi();
		selectDuel2.Combi();
		do {
			selectDuel.Attack();
			selectDuel2.Attack();

		} while (gagneCompute < PropertiesHelper.getNbChiffre() && gagneUser < PropertiesHelper.getNbChiffre()
				&& tentativesUser < PropertiesHelper.getNbEssai());

		duelResults();

	}

	private static void duelResults() {

		if (gagneCompute == PropertiesHelper.getNbChiffre()) {
			System.out.println("L'ordinateur a gagne ");
		}

		if (gagneUser == PropertiesHelper.getNbChiffre()) {
			System.out.println("Vous avez gagne ! ");
		} else if (tentativesUser == PropertiesHelper.getNbEssai()
				&& tentativesCompute == PropertiesHelper.getNbEssai()) {
			System.out.println("Personne n'a gagne, personne n'a perdu, on vit dans un monde formidable");

		}

		whatsNext();
	}

	public void initializeValue() {

		gagneCompute = 0;
		gagneUser = 0;
		tentativesCompute = 0;
		tentativesUser = 0;
		bienPlace = 0;
		malPlace = 0;


	}

	protected static void whatsNext() {
		Game_Interface select;
		int securityLoop = 0;
		do { // boucle en cas d'erreur de saisie
			try {
				securityLoop = 0;
				int retry = 0;
				Scanner sc = new Scanner(System.in);
				System.out.println("Voulez vous :");
				System.out.println("1. Jouer au meme jeu");
				System.out.println("2. Retourner au menu");
				System.out.println("3. Quitter le programme");

				retry = sc.nextInt();

				if (retry == 1) {
					logger.trace(" Le jeu est termine, l'utilisateur rejoue au meme jeux ");
					AbstractGAME.Menu();
//					break;
				} else if (retry == 2) {
					logger.trace(" Le jeu est termine, l'utilisateur veut retourner au menu ");
					AbstractGAME.gameSelection();
					
				} else {
					System.out.println("Merci d'avoir joue et a bientot");
					logger.trace(" Le jeu est termine, l'utilisateur a quitte ");
					System.exit(-1);
				}

			} catch (InputMismatchException f) {
				logger.warn("La saisie ne semble pas bonne, merci de recommencer :");
				securityLoop++;
			}

		} while (securityLoop == 1);// fin de la boucle

	}
	/* Methodes Abstraites */

	public abstract void Results();



	/* Arguments prives */
	private static int selectGame;
	private static int selectMode;

}

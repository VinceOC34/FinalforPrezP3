package com.vincentmartinez.logicgame.implementation;

public interface Game_Interface {
	
	void Combi();
	void Attack();
	void Play();
	void initializeValue();
	void Results();
	

}

package com.vincentmartinez.plusoumoins;

import java.util.Random;

import com.vincentmartinez.logicgame.implementation.AbstractDefender;
import com.vincentmartinez.logicgame.implementation.PropertiesHelper;

public class PLM_Defender extends AbstractDefender {

	public PLM_Defender() {
		this.Play();
	}

	public void initializeValue() {
		super.initializeValue();

		max = new int[PropertiesHelper.getNbChiffre()];
		min = new int[PropertiesHelper.getNbChiffre()];

		/*
		 * ici je determine le max de la boucle random, qui genere l'attaque de l'ordi
		 * en apprenant de ses erreurs
		 */

		for (int i = 0; i < PropertiesHelper.getNbChiffre(); i++) {
			max[i] = 10;
		}

		/*
		 * ici je determine le min de la boucle random, qui genere l'attaque // de
		 * l'ordi en apprenant de ses erreurs
		 */

		for (int j = 0; j < PropertiesHelper.getNbChiffre(); j++) {
			min[j] = 0;
		}
		ComputeAttack.clear();
		UserCombi.clear();
	}

	public void Attack() {
		gagneCompute = 0;

		do {
			// int []computAttack = new int[getNbChiffre()];

			Random rand = new Random();

			System.out.println("l'ordinateur effectue son attaque " + (tentativesCompute + 1) + " sur "
					+ PropertiesHelper.getNbEssai());

			ComputeAttack.clear();
			for (int k = 0; k < PropertiesHelper.getNbChiffre(); k++) {
				ComputeAttack.add(rand.nextInt(max[k] - min[k]) + min[k]);
				// ComputeAttack.add(ComputeAttack.get(k));
				System.out.print(ComputeAttack.get(k) + "|");

			}
			System.out.println();
			// protected void ComputeCheck() {
			for (int l = 0; l < PropertiesHelper.getNbChiffre(); l++) {

				if (ComputeAttack.get(l) == UserCombi.get(l)) {
					max[l] = ComputeAttack.get(l) + 1;
					max[l] = max[l];
					min[l] = ComputeAttack.get(l);
					min[l] = min[l];
					System.out.print(UserCombi.get(l)+"|");
					gagneCompute++;
				} else if (ComputeAttack.get(l) > UserCombi.get(l)) {
					System.out.print("-"+"|");
					max[l] = ComputeAttack.get(l);
					max[l] = max[l];
				} else {
					System.out.print("+"+"|");
					min[l] = (ComputeAttack.get(l) + 1);
					min[l] = min[l];
				}

			}
			System.out.println();
			tentativesCompute++;

		} while (ComputeAttack.size() < PropertiesHelper.getNbChiffre());
	}

	private int[] max;
	private int[] min;
}

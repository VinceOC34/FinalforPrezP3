package com.vincentmartinez.plusoumoins;

import com.vincentmartinez.logicgame.implementation.AbstractChallenger;
import com.vincentmartinez.logicgame.implementation.PropertiesHelper;

public class PLM_Challenger extends AbstractChallenger {

	public PLM_Challenger() {


//		this.Combi();
//		this.Attack();
		this.Play();
	
	}

	public void Attack() {
		super.Attack();
		ChallengerPartAnalysePLM();
	}


	
	public static void ChallengerPartAnalysePLM() {

		for (int l = 0; l < PropertiesHelper.getNbChiffre(); l++) {

			if (UserAttack.get(l) == ComputeCombi.get(l)) {
				System.out.print(UserAttack.get(l)+"|");
				gagneUser++;
			} else if (UserAttack.get(l) > ComputeCombi.get(l)) {
				System.out.print("-"+"|");

			} else {
				System.out.print("+"+"|");

			}
			
		}
		tentativesUser++;
		System.out.println("");
	}


	
		
	

}

package com.vincentmartinez.mastermind;

import java.util.Iterator;
import java.util.Random;

import com.vincentmartinez.logicgame.implementation.AbstractDefender;
import com.vincentmartinez.logicgame.implementation.PropertiesHelper;

public class MM_Defender extends AbstractDefender {

	public MM_Defender() {

		this.Play();
	}


	public void initializeValue() {
		super.initializeValue();
		/*
		 * je vide d'abord les m�moires de toutes les collections dans le cas ou je
		 * rejouerai
		 */
		chiffresPossibles.clear();// Attention cela correspond uniquement au MM
		ComputeAttack.clear();
		computLoading.clear();
		UserCombi.clear();
		/*
		 * puis j'initialise la collection chiffresPossibles, qui sert de pioche a
		 * l'attaque de l'ordinateur
		 * 
		 */

		for (int i = 0; i < 10; i++) {
			// (soit de 1 a 9) dans un Array.
			chiffresPossibles.add(i);
		}
	}

	public void Attack() {

		
		bienPlace = 0;
		malPlace = 0;
		if (tentativesCompute < PropertiesHelper.getNbEssai() * 0.66) {
			firstHalfComputeAttack();
		}

		else if (tentativesCompute >= PropertiesHelper.getNbEssai() * 0.66 && tentativesCompute < PropertiesHelper.getNbEssai()) {
			secondHalfComputeAttack();
		}
		tentativesCompute++;
	}

	/*
	 * ci dessous les 3 m�thodes private d�finissant l'attaque sp�cifique du mode
	 * defenseur MM
	 */

	private void implementComputeAttackSecondHalf() {
		Random rand = new Random();
		ComputeAttack.clear();
		while (ComputeAttack.size() < PropertiesHelper.getNbChiffre()) {
			while (ComputeAttack.size() < computLoading.size()) {
				securityLoop = 0;
				int pickLoad = rand.nextInt(computLoading.size());
				if (ComputeAttack.contains(computLoading.get(pickLoad))) {
					securityLoop = 1;
				} else {
					ComputeAttack.add(computLoading.get(pickLoad));
				}
			}
			int pickChiffres = rand.nextInt(chiffresPossibles.size());

			ComputeAttack.add(chiffresPossibles.get(pickChiffres));

		}
		Iterator<Integer> IComputeAttack2 = ComputeAttack.iterator();
		while (IComputeAttack2.hasNext()) {
			System.out.print(IComputeAttack2.next() + "|");
		}
	}

	/*
	 * la premiere partie Attaque teste des chiffres uniques en combinaison, pourF
	 * faire le tri dans les chiffres a conserver. Ceci concerne a peu pres 2/3 des
	 * essais
	 */
	private void firstHalfComputeAttack() {

		bienPlace = 0;
		malPlace = 0;

		ComputeAttack.clear();

		System.out.println();
		System.out.println("L'ordinateur effectue son attaque " + (tentativesCompute + 1) + " sur " + PropertiesHelper.getNbEssai());

		do {
			securityLoop = 0;
			Random rand = new Random();
			nb = rand.nextInt(chiffresPossibles.size());

			/*
			 * Si ComputLoading contient d�ja ce chiffre, c'est que ce chiffre a �t� test�
			 * et valid� on g�n�re donc un autre Random
			 */
			if (computLoading.contains(nb)) {
				securityLoop = 1;
			}

		} while (securityLoop == 1);

		/*
		 * Si le chiffre est detecte comme bien place, il tombe dans l'Array
		 * ComputLoading, qui servira ensuite a l'attaque aleatoire
		 */
		while (ComputeAttack.size() < PropertiesHelper.getNbChiffre()) {

			ComputeAttack.add(chiffresPossibles.get(nb));

		}
		Iterator<Integer> IComputeAttack = ComputeAttack.iterator();
		while (IComputeAttack.hasNext()) {
			System.out.print(IComputeAttack.next() + "|");
		}
		;
		for (int k = 0; k < PropertiesHelper.getNbChiffre(); k++) {
			/*
			 * Je charge computAttack, avec le nombre choisit aleatoirement (au debut
			 * j'utilise x fois le meme chiffre)
			 */
			if (ComputeAttack.get(k) == UserCombi.get(k)) {
				/*
				 * Si computAttack correspond bien a� UserImput, on le charge dans le tableau
				 * stockant les bons resultats
				 */
				computLoading.add(ComputeAttack.get(k));
				bienPlace++;
				gagneCompute++;
				if (chiffresPossibles.contains(ComputeAttack.get(k))) {
					chiffresPossibles.remove(chiffresPossibles.indexOf(ComputeAttack.get(k)));
				}
			} else if (ComputeAttack.get(k) != UserCombi.get(k)) {
				if (ComputeAttack.contains(UserCombi.get(k))) {
					malPlace++;
				}

				else if (chiffresPossibles.contains(ComputeAttack.get(k))) {
					chiffresPossibles.remove(chiffresPossibles.indexOf(ComputeAttack.get(k)));
				}

				/*
				 * Si il ne fait pas parti de la combinaison, le besoin de ce chiffre passe a� 0
				 */
			}

		}
		System.out.println();
		System.out.println("bienPlace = " + bienPlace);
		System.out.println("malPlace = " + malPlace);
//		System.out.print("computLoading = ");
//		Iterator<Integer> ltest = computLoading.iterator();
//		while (ltest.hasNext()) {
//			System.out.print(ltest.next());
//		}
		System.out.println();
//		System.out.println("chiffres possibles restant : ");
//		Iterator<Integer> ltest2 = chiffresPossibles.iterator();
//		while (ltest2.hasNext()) {
//			System.out.print(ltest2.next() + " | ");
//		}
//		tentativesCompute++;
	}

	/*
	 * la deuxi�me partie se sert du tri effectue plus haut, et propose cette foisF
	 * des combinaisons a plusieurs chiffres
	 */

	private void secondHalfComputeAttack() {

		bienPlace = 0;
		malPlace = 0;

		System.out.println();
		System.out.println("L'ordinateur effectue son attaque " + (tentativesCompute + 1) + " sur " + PropertiesHelper.getNbEssai());

		/*
		 * Si computLoading ne contient pas autant de chiffre que necessaire, je
		 * surcharge computLoading, en int�grant les chiffres non test�s (encore � 1
		 * dans le tableau verificationBesoin, qui sert � determiner les quantit�s.
		 */

		this.implementComputeAttackSecondHalf();

		System.out.println();
		for (int o = 0; o < PropertiesHelper.getNbChiffre(); o++) {

			if (ComputeAttack.get(o) == UserCombi.get(o)) {
				bienPlace++;
				gagneCompute++;
			} else if (ComputeAttack.contains(UserCombi.get(o))) {
				malPlace++;
			}
		}

		System.out.println();
		System.out.println("bienPlace = " + bienPlace);
		System.out.println("malPlace = " + malPlace);
//		tentativesCompute++;

	}

}

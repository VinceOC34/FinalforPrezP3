package com.vincentmartinez.mastermind;

import com.vincentmartinez.logicgame.implementation.AbstractChallenger;
import com.vincentmartinez.logicgame.implementation.PropertiesHelper;

public class MM_Challenger extends AbstractChallenger {

public MM_Challenger() {
	
//	this.Combi();
//	this.Attack();
	this.Play();
		
	}


	public void Attack() {

		super.Attack();
		this.ChallengerPartAnalyseMM();
	}

	private void ChallengerPartAnalyseMM() {

		for (int l = 0; l < PropertiesHelper.getNbChiffre(); l++) {

			if (UserAttack.get(l) == ComputeCombi.get(l)) {
				bienPlace++;
				gagneUser++;
			} else if (UserAttack.contains(ComputeCombi.get(l))) {
				malPlace++;

			}

		}
		System.out.println("bienPlace = " + bienPlace);
		System.out.println("malPlace = " + (malPlace));
		tentativesUser++;
		System.out.println();
	}
	

		
	}


